package com.example.comunicacionandroid_apirest

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.widget.AbsListView
import android.widget.Button
import android.widget.Toast

class Principal : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_principal)

        var buttonListado = findViewById<Button>(R.id.buttonListado)
        var buttonArlarma = findViewById<Button>(R.id.buttonArlarma)
        var buttonLlamada = findViewById<Button>(R.id.buttonLlamada)
        var buttonCamara = findViewById<Button>(R.id.buttonCamara)
        var buttonMapa = findViewById<Button>(R.id.buttonMapa)
        var btnComprador = findViewById<Button>(R.id.btnComprador)
        var btnVendedor = findViewById<Button>(R.id.btnVendedor)

        buttonListado.setOnClickListener {
            startActivity(Intent(this, imagenRecyclerView::class.java))
        }
         btnComprador.setOnClickListener {

             Toast.makeText(this, "Datos guardados correctamente 1", Toast.LENGTH_LONG).show()
             startActivity(Intent(this, SellerConfiguration::class.java))

         }
         btnVendedor.setOnClickListener {

            Toast.makeText(this, "Datos guardados correctamente 1", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, BuyerConfiguration::class.java))
        }
        buttonArlarma.setOnClickListener {


            try {
                var alarma = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "¡¡Despiertaaa!!")
                    .putExtra(AlarmClock.EXTRA_HOUR, 7)
                    .putExtra(AlarmClock.EXTRA_MINUTES, 30)
                startActivity(alarma)

            }catch (e:Exception){
                e.printStackTrace()
            }

        }

        buttonCamara.setOnClickListener {
            var camara = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

            startActivity(camara)
        }


        buttonMapa.setOnClickListener {
            var mapa = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.es/maps/place/Momart+Theatre/@36.5404261,-6.2880594,15.11z/data=!4m5!3m4!1s0xd0dd17092fbb8d1:0xaf6cd3492339f727!8m2!3d36.5391367!4d-6.2905961?hl=es"))
            mapa.setPackage("com.google.android.apps.maps")

            startActivity(mapa)
        }

        buttonLlamada.setOnClickListener {
            var llamada = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" +34567876908))

            startActivity(llamada)
        }
    }
}