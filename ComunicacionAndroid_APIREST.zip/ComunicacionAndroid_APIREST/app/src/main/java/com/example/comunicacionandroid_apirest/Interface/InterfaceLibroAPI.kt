package com.example.comunicacionandroid_apirest.Interface

import com.example.comunicacionandroid_apirest.Model.Libro
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path


interface InterfaceLibroAPI {

    @GET(value = "libros/")
    fun getAllLibros(): Call<List<Libro>>  //Call de retrofit

    @GET(value = "libros/{id}")  //Pasamos un id de objeto para recuperar sólo un objeto. Usamos la anotacion @Path antes de la variable a enviar
    fun getLibroById(@Path(value = "id") id:Int): Call<Libro>

    @POST(value = "libros/{id}")  //Se usa la etiqueta de Retrofil @Body cuando se envía a la API un paquete de información
    fun postLibroById(@Path(value = "id") id:Int, @Body libro: Libro?):Call<Libro>

}