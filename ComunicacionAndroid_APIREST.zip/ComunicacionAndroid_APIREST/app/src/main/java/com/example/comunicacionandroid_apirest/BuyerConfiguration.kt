package com.example.comunicacionandroid_apirest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class BuyerConfiguration : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buyer_configuration)
    }
}

