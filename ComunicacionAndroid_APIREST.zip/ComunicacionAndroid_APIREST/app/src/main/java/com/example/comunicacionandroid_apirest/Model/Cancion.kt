package com.example.comunicacionandroid_apirest.Model

data class Cancion(
    val id:String,
    val albumId:String,
    val title:String,
    val image:String,
    val icon:String
)
