package com.example.comunicacionandroid_apirest

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.comunicacionandroid_apirest.Model.Cancion

class ElementoAdapter(var context: Context,
                      var canciones: List<Cancion>,
                      private val itemClickListener: onItemListener
                      ): RecyclerView.Adapter<ElementoAdapter.ViewHolder>() {

    interface onItemListener{

        fun onImagenItinerarioClick(image: String)
        fun onItemClick(albumId: String)


    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        //Aqui se infla la vista xml con datos

        val view = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.layout_cancion,parent,false)
        return ViewHolder(view)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        var cancion = canciones[position]
        holder.bind(cancion,context)
    }

    override fun getItemCount(): Int {
        return canciones.size
    }

    inner class ViewHolder(val view: View): RecyclerView.ViewHolder(view){

        var idCancion = view.findViewById<TextView>(R.id.idCancion)
        var idAlbum = view.findViewById<TextView>(R.id.idAlbum)
        var titleCancion = view.findViewById<TextView>(R.id.title)
        var imagenCancion = view.findViewById<ImageView>(R.id.idImagen)
        var iconoCancion = view.findViewById<ImageView>(R.id.idIcon)



        fun bind(cancion: Cancion,context: Context){
              idCancion.text = cancion.id
              idAlbum.text = cancion.albumId
              titleCancion.text = cancion.title
              Log.i("IMAGEN","Imagen: ${cancion.image}")
              Log.i("ICONO","Icono: ${cancion.icon}")
              Glide.with(context).load(cancion.image).into(imagenCancion);
              Glide.with(context).load(cancion.icon).into(iconoCancion);
              view.setOnClickListener {
                  itemClickListener.onItemClick(cancion.albumId)
                  //Log.i("CLICK","Pulsamos ${cancion.albumId}")
                  //Toast.makeText(context,"Confirmado ${cancion.albumId}",Toast.LENGTH_LONG).show()
                  Toast.makeText(view.context,"Hola",Toast.LENGTH_LONG).show()}
                  imagenCancion.setOnClickListener {
                      itemClickListener.onImagenItinerarioClick(cancion.image)
                  }




        }
    }
}