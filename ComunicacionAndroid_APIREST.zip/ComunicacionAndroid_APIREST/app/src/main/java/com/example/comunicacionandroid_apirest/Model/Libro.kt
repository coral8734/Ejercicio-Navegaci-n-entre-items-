package com.example.comunicacionandroid_apirest.Model

class Libro(

    var id:Integer,
    var titulo:String,
    var editorial:String,
    var autor:String)



