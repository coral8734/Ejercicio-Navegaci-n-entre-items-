package com.example.comunicacionandroid_apirest

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatImageView

class nuevaImageView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : AppCompatImageView(context, attrs) {

    var ratioImage: Float = 1f

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)

        var width = measuredWidth
        var height = measuredHeight

        if (width == 0 && height == 0){
            return
        }

        if(width > 0){
            height = (width*ratioImage).toInt()
        }else if(height >0){
            width = (height/ratioImage).toInt()
        }

        setMeasuredDimension(width,height)


    }
}