package com.example.comunicacionandroid_apirest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.RecyclerView
import com.example.comunicacionandroid_apirest.Interface.InterfaceLibroAPI
import com.example.comunicacionandroid_apirest.Model.Cancion
import com.example.comunicacionandroid_apirest.Model.Libro
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory

public class MainActivity : AppCompatActivity(),ElementoAdapter.onItemListener {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.e("API -> DAM2", "Entramos en funcion onCreate")
        setContentView(R.layout.activity_main)

        setupRecyclerView1()


        //var apiVisorTextView = findViewById<TextView>(R.id.textView)

       // val imageView1 =  findViewById<ImageView>(R.id.iv1);
        //val imageView1 =  findViewById<ImageView>(R.id.iv2);
        //val imageView1 =  findViewById<ImageView>(R.id.iv3);
        //val imageView1 =  findViewById<ImageView>(R.id.iv3);
        //val imageView1 =  findViewById<ImageView>(R.id.iv1);
        //val imageView1 =  findViewById<ImageView>(R.id.iv1);


        //Glide.with(this).load("https://www.cadizturismo.com/storage/app/media/uploaded-files/p-cadiz_turismo.jpg").into(imageView1);

        //getLibros(apiVisorTextView)
        //getImagenes()

    }

    private fun setupRecyclerView1(){



        var canciones: List<Cancion> = listOf(
            Cancion(id = "1", albumId = "Itinerario 1",title="Vista de Cádiz",image="https://www.cadizturismo.com/storage/app/media/uploaded-files/p-cadiz_turismo.jpg",icon="https://procom.camarasandalucia.com/wp-content/uploads/2019/07/fav-icon.jpg"),
            Cancion(id = "2", albumId = "Itinerario 2",title="La catedral de Cádiz",image="https://upload.wikimedia.org/wikipedia/commons/f/f8/Catedral_de_C%C3%A1diz.jpg",icon="https://procom.camarasandalucia.com/wp-content/uploads/2019/07/fav-icon.jpg"),
            Cancion(id = "3", albumId = "Itinerario 3",title="Vista de Cádiz",image="https://www.cadizturismo.com/storage/app/media/uploaded-files/p-cadiz_turismo.jpg",icon="https://procom.camarasandalucia.com/wp-content/uploads/2019/07/fav-icon.jpg"),
            Cancion(id = "4", albumId = "Itinerario 4",title="La catedral de Cádiz",image="https://upload.wikimedia.org/wikipedia/commons/f/f8/Catedral_de_C%C3%A1diz.jpg",icon="https://procom.camarasandalucia.com/wp-content/uploads/2019/07/fav-icon.jpg"),
            Cancion(id = "5", albumId = "Itinerario 5",title="Vista de Cádiz",image="https://www.cadizturismo.com/storage/app/media/uploaded-files/p-cadiz_turismo.jpg",icon="https://procom.camarasandalucia.com/wp-content/uploads/2019/07/fav-icon.jpg"),
            Cancion(id = "6", albumId = "Itinerario 6",title="La catedral de Cádiz",image="https://upload.wikimedia.org/wikipedia/commons/f/f8/Catedral_de_C%C3%A1diz.jpg",icon="https://procom.camarasandalucia.com/wp-content/uploads/2019/07/fav-icon.jpg"),
            Cancion(id = "7", albumId = "Itinerario 7",title="Vista de Cádiz",image="https://www.cadizturismo.com/storage/app/media/uploaded-files/p-cadiz_turismo.jpg",icon="https://procom.camarasandalucia.com/wp-content/uploads/2019/07/fav-icon.jpg"),
            Cancion(id = "8", albumId = "Itinerario 8",title="La catedral de Cádiz",image="https://upload.wikimedia.org/wikipedia/commons/f/f8/Catedral_de_C%C3%A1diz.jpg",icon="https://procom.camarasandalucia.com/wp-content/uploads/2019/07/fav-icon.jpg")
        )


        var recycler = findViewById<RecyclerView>(R.id.rvCanciones)
        recycler.adapter = ElementoAdapter(this, canciones,this)
        recycler.addItemDecoration(DividerItemDecoration(this,DividerItemDecoration.VERTICAL))


    }

    private fun getImagenes(apiVisorTextView: TextView) {

        Log.e("API -> DAM2", "Entrando en función getImagenes")

        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("")
            .addConverterFactory(GsonConverterFactory.create())
            .build()


        val libService = retrofit.create<InterfaceLibroAPI>(InterfaceLibroAPI::class.java)


        libService.getAllLibros().enqueue(object : Callback<List<Libro>> {

            override fun onResponse(call: Call<List<Libro>>, response: Response<List<Libro>>?) {


                var listaLibros = arrayListOf<Libro>()
                listaLibros = response?.body() as ArrayList<Libro>

                for(libro in listaLibros){
                   var content = ""
                   println("El identificador del cliente es:  ${libro.id.toString()}")
                   println("La edad del cliente es: ${libro.autor.toString()}")
                   println("El numero de cuenta del cliente es: ${libro.titulo.toString()}")
                   println("La cantidad de saldo del cliente es: ${libro.editorial.toString()}")
                   println("\n")
                   content += "ID: " + libro.id.toString() + "\n"
                   content += "Autor: " + libro.autor.toString()+ "\n"
                   content += "Editorial: " + libro.editorial.toString() + "\n"

                   apiVisorTextView.append(content)
                 }

               // Log.i(TAG_LOGS, Gson().toJson(libros))
            }

            override fun onFailure(call: Call<List<Libro>>?, t: Throwable) {
                t?.printStackTrace()
            }


        })
    }


    private fun getLibros(apiVisorTextView: TextView) {

        Log.e("API -> DAM2", "Entrando en función getLibros")

        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.0.27:8081")
            .addConverterFactory(GsonConverterFactory.create())
            .build()


        val libService = retrofit.create<InterfaceLibroAPI>(InterfaceLibroAPI::class.java)


        libService.getAllLibros().enqueue(object : Callback<List<Libro>> {

            override fun onResponse(call: Call<List<Libro>>, response: Response<List<Libro>>?) {


                var listaLibros = arrayListOf<Libro>()
                listaLibros = response?.body() as ArrayList<Libro>

                for(libro in listaLibros){
                    var content = ""
                    println("El identificador del cliente es:  ${libro.id.toString()}")
                    println("La edad del cliente es: ${libro.autor.toString()}")
                    println("El numero de cuenta del cliente es: ${libro.titulo.toString()}")
                    println("La cantidad de saldo del cliente es: ${libro.editorial.toString()}")
                    println("\n")
                    content += "ID: " + libro.id.toString() + "\n"
                    content += "Autor: " + libro.autor.toString()+ "\n"
                    content += "Editorial: " + libro.editorial.toString() + "\n"

                    apiVisorTextView.append(content)
                }

                // Log.i(TAG_LOGS, Gson().toJson(libros))
            }

            override fun onFailure(call: Call<List<Libro>>?, t: Throwable) {
                t?.printStackTrace()
            }


        })
    }

    override fun onImagenItinerarioClick(image: String) {

        val intent = Intent(this, imagenRecyclerView::class.java)
        intent.putExtra("imageUrl", image)
        startActivity(intent)
    }

    override fun onItemClick(albumId: String) {
        Toast.makeText(this,"Funciona el nuevo Toast", Toast.LENGTH_LONG).show()
    }

   
}