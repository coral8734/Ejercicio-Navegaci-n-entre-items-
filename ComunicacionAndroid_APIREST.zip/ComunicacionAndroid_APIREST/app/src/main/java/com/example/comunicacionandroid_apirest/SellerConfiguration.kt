package com.example.comunicacionandroid_apirest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SellerConfiguration : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seller_configuration)
    }
}