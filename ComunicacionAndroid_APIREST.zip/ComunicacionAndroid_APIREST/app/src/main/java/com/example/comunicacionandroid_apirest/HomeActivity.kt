package com.example.comunicacionandroid_apirest


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.core.content.ContextCompat
import com.google.firebase.ktx.Firebase
import com.google.firebase.firestore.ktx.firestore




class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)



        var radioG = findViewById<RadioGroup>(R.id.RadioG)
        var textViewEmail = findViewById<TextView>(R.id.textViewEmail)
        var radioButtonComrador = findViewById<RadioButton>(R.id.radioButtonComprador)
        var radioButtonProveedor = findViewById<RadioButton>(R.id.radioButtonProveedor)
        var txtName = findViewById<EditText>(R.id.txtName)
        var checkBoxPagar = findViewById<CheckBox>(R.id.checkBoxPagar)
        var txtPhone = findViewById<EditText>(R.id.txtPhone)
        var txtAddress = findViewById<EditText>(R.id.txtAddress)
        var buttonGuardar = findViewById<Button>(R.id.buttonGuardar)

        val bundle: Bundle? = intent.extras
        val email:String? = bundle?.getString("email")
        textViewEmail?.text="Correo electrónico"

        val db = Firebase?.firestore


        buttonGuardar?.setOnClickListener {

            //startActivity(Intent(this, Principal::class.java))


            val datosUsuario = hashMapOf(
                "nombre" to txtName?.text.toString(),
                "comprador" to radioButtonComrador?.isChecked,
                "vendedor" to radioButtonProveedor?.isChecked,
                "direccion" to txtAddress?.text.toString(),
                "telefono" to txtPhone?.text.toString()
            )



            Log.d("TAG----->", "${txtName?.text.toString()}")

            db.collection("CESJUANPablo")?.document(txtName?.text.toString())
                .set(datosUsuario)

            startActivity(Intent(this, Principal::class.java))

        }
    }




}







